public enum PlaylistNodeType {
	Internal,
	Leaf,
}
