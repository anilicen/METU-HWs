import java.util.ArrayList;


public class PlaylistTree {
	
	public PlaylistNode primaryRoot;		//root of the primary B+ tree
	public PlaylistNode secondaryRoot;	//root of the secondary B+ tree
	public PlaylistTree(Integer orderForPlaylistTree) {
		PlaylistNode.order = orderForPlaylistTree;
		primaryRoot = new PlaylistNodePrimaryLeaf(null);
		primaryRoot.level = 0;
		secondaryRoot = new PlaylistNodeSecondaryLeaf(null);
		secondaryRoot.level = 0;
	}
	
	public void addSong(CengSong song) {
		Integer orderForPlaylistTreex2 = 2*PlaylistNode.order;
		primaryAddSong(song,  orderForPlaylistTreex2);
		secondaryAddSong(song,  orderForPlaylistTreex2);
	}
	public void secondaryAddSong(CengSong song, Integer orderForPlaylistTreex2){
		PlaylistNodeSecondaryIndex srcSec =new PlaylistNodeSecondaryIndex(null);
		PlaylistNodeSecondaryLeaf srcSecLeaf = new PlaylistNodeSecondaryLeaf(null);
		String genre = song.genre();


			if(secondaryRoot.getType() ==PlaylistNodeType.Internal){

			srcSec=(PlaylistNodeSecondaryIndex) secondaryRoot;
			while(srcSecLeaf.getParent()==null){
				for(int i=0; i < srcSec.genreCount() ; i++){

					if(srcSec.genreAtIndex(i).compareTo(genre)>0){ //if(genreAtIndex > genre)!!!!!!!!11
						if(srcSec.getChildrenAt(i).getType()==PlaylistNodeType.Internal){
							srcSec = (PlaylistNodeSecondaryIndex)srcSec.getChildrenAt(i);
							break;
						}
						else {
							srcSecLeaf = (PlaylistNodeSecondaryLeaf)srcSec.getChildrenAt(i);
							break;
						}
					}
					else if(i==srcSec.genreCount()-1){
						if(srcSec.getChildrenAt(i+1).getType()==PlaylistNodeType.Internal){
							srcSec = (PlaylistNodeSecondaryIndex)srcSec.getChildrenAt(i+1);
							break;
						}
						else{
							
							srcSecLeaf = (PlaylistNodeSecondaryLeaf)srcSec.getChildrenAt(i+1);
							break;
						}
					}
				}
			}
		}

		else if(srcSecLeaf.getParent()==null){

			srcSecLeaf=(PlaylistNodeSecondaryLeaf) secondaryRoot;
		}
		if(srcSecLeaf.genreCount()==0) {
			
			srcSecLeaf.addSong(0,song);
		}
		else{

			for(int i=0;i<srcSecLeaf.genreCount(); i++){
				

				if(srcSecLeaf.genreAtIndex(i).compareTo(genre)>=0){	//genreAtIndex> genre
					
					if(srcSecLeaf.genreAtIndex(i).compareTo(genre)==0){
					ArrayList<CengSong> bucket = srcSecLeaf.getSongBucket().get(i);
					bucket.add(song);
					break;
				}
				else {
					srcSecLeaf.addSong(i, song);
					break;
				}
			}
				else if(i==srcSecLeaf.genreCount()-1){
					srcSecLeaf.addSong(i+1, song);
					break;
				}
				
			}
		}
		if(srcSecLeaf.genreCount()>orderForPlaylistTreex2){

			ArrayList<PlaylistNode> split_leaves = split_leaves_secondary(srcSecLeaf);
			PlaylistNodeSecondaryLeaf first = (PlaylistNodeSecondaryLeaf) split_leaves.get(0);
			PlaylistNodeSecondaryLeaf second = (PlaylistNodeSecondaryLeaf) split_leaves.get(1);
			String middleElement = second.genreAtIndex(0);
			PlaylistNodeSecondaryIndex parent = (PlaylistNodeSecondaryIndex) srcSecLeaf.getParent();
			int index=0;
			if(parent == null){

				PlaylistNodeSecondaryIndex root = new PlaylistNodeSecondaryIndex(null);
				root.addGenre(0, middleElement);
				first.setParent(root);
				second.setParent(root);
				root.addChildren(0, first);
				root.addChildren(1, second);
				secondaryRoot = root;
			}
			else{

				for(int i = 0;i<parent.genreCount();i++){
				

					if(parent.genreAtIndex(i).compareTo(genre)>0){
						parent.addGenre(i, middleElement);
						index = i;
						break;
					}
					else if(i==parent.genreCount()-1){
						parent.addGenre(i+1, middleElement);
						index = i+1;
						break;
					}
			}
			PlaylistNode root = recursiveCallForSecondary(secondaryRoot,parent,index,first,second);
					secondaryRoot = root;
		}
	}
	return;
	}




	public void primaryAddSong(CengSong song, Integer orderForPlaylistTreex2){
		PlaylistNodePrimaryIndex sourcePrimary = new PlaylistNodePrimaryIndex(null);
		PlaylistNodePrimaryLeaf sourceLeafPrimary = new PlaylistNodePrimaryLeaf(null);
		
		int audioId = song.audioId();
		if(primaryRoot.getType() == PlaylistNodeType.Internal){

			sourcePrimary = (PlaylistNodePrimaryIndex) primaryRoot;

			while(sourceLeafPrimary.getParent()==null){
				for(int i=0;i<sourcePrimary.audioIdCount();i++){

					if(audioId < sourcePrimary.audioIdAtIndex(i)){
					
						if(sourcePrimary.getChildrenAt(i).getType()==PlaylistNodeType.Internal){
							sourcePrimary = (PlaylistNodePrimaryIndex) sourcePrimary.getChildrenAt(i);
							break;
						}
 
						else{
							sourceLeafPrimary = (PlaylistNodePrimaryLeaf)sourcePrimary.getChildrenAt(i);
							break;
						}
					}
					else if(i==sourcePrimary.audioIdCount()-1){
					
						if(sourcePrimary.getChildrenAt(i+1).getType()==PlaylistNodeType.Internal){
							sourcePrimary= (PlaylistNodePrimaryIndex)sourcePrimary.getChildrenAt(i+1);
							break;
						}
					
						else{
							sourceLeafPrimary=(PlaylistNodePrimaryLeaf)sourcePrimary.getChildrenAt(i+1);
							break;
						}

					}



				}
			}
		}	
		else if(sourceLeafPrimary.getParent()==null){

			sourceLeafPrimary = (PlaylistNodePrimaryLeaf) primaryRoot;
		}

		if(sourceLeafPrimary.songCount()==0){ 
			
			sourceLeafPrimary.addSong(0, song);
		
		}

		else{

			for(int i=0;i<sourceLeafPrimary.songCount(); i++){
				if(audioId < sourceLeafPrimary.audioIdAtIndex(i)){
					sourceLeafPrimary.addSong(i,song);
					break;
				}
				else if(i==sourceLeafPrimary.songCount()-1){
					sourceLeafPrimary.addSong(i+1,song);
					break;
				}
				else{
					continue;
				}
			}
		}
		
		//overflow happens
		if(sourceLeafPrimary.songCount()>orderForPlaylistTreex2){
			ArrayList<PlaylistNode> spl_lvs = split_leaves_primary(sourceLeafPrimary);
			PlaylistNodePrimaryLeaf firstOfTheSplittedLeaves = (PlaylistNodePrimaryLeaf) spl_lvs.get(0);  
			PlaylistNodePrimaryLeaf lastOfTheSplittedLeaves = (PlaylistNodePrimaryLeaf) spl_lvs.get(1);
			int middleElementOfTheSplittedLeaves = lastOfTheSplittedLeaves.audioIdAtIndex(0);
			PlaylistNodePrimaryIndex parent = (PlaylistNodePrimaryIndex) sourceLeafPrimary.getParent();
			int IndexOfTheInsertingPlaceForChildren=0;
			if(parent == null){

				PlaylistNodePrimaryIndex root = new PlaylistNodePrimaryIndex(null);
				root.addAudioId(0, middleElementOfTheSplittedLeaves);
				firstOfTheSplittedLeaves.setParent(root);
				lastOfTheSplittedLeaves.setParent(root);
				root.addChildren(0, firstOfTheSplittedLeaves);
				root.addChildren(1, lastOfTheSplittedLeaves);
				primaryRoot = root;
			}
			else{
				for(int i = 0;i<parent.audioIdCount();i++){
					if(middleElementOfTheSplittedLeaves< parent.audioIdAtIndex(i)){
						parent.addAudioId(i, middleElementOfTheSplittedLeaves);
						IndexOfTheInsertingPlaceForChildren = i;
						break;
					}

					else if(i==parent.audioIdCount()-1){
						parent.addAudioId(i+1, middleElementOfTheSplittedLeaves);
						IndexOfTheInsertingPlaceForChildren = i+1;
						break;
					}
					else{
						if(i%5==0){
						PlaylistNodePrimaryIndex count = new PlaylistNodePrimaryIndex(null);

						for(int counter = 0; counter<100;counter++){
							if(counter<50)
							count.addChildren(counter, firstOfTheSplittedLeaves);
							else{
								count.removeChildren(99-counter);
							}
						}
					}
						continue;
					}

				}
					PlaylistNode root = recursiveCallForPrimary(primaryRoot,parent,IndexOfTheInsertingPlaceForChildren,firstOfTheSplittedLeaves,lastOfTheSplittedLeaves);
					primaryRoot = root;
			}
		}
		
		return;
	}
	private PlaylistNode recursiveCallForPrimary(PlaylistNode primaryRoot, PlaylistNode sourcePrimary,
			int IndexOfTheInsertingPlaceForChildren, PlaylistNode firstOfTheSplittedLeaves, PlaylistNode lastOfTheSplittedLeaves) {
				int orderForPlaylistTree = PlaylistNode.order;
				PlaylistNodePrimaryIndex parent = new PlaylistNodePrimaryIndex(null);
				PlaylistNodePrimaryIndex first_int= new PlaylistNodePrimaryIndex(null);
				PlaylistNodePrimaryIndex second_int= new PlaylistNodePrimaryIndex(null);
				PlaylistNodePrimaryIndex count = new PlaylistNodePrimaryIndex(null);
				parent = (PlaylistNodePrimaryIndex) sourcePrimary;
				PlaylistNodePrimaryIndex root = new  PlaylistNodePrimaryIndex(null);
				if(parent.audioIdCount()<=2*orderForPlaylistTree)//done there is no push up
				{			
					for(int counter = 0; counter<100;counter++){
						if(counter<50)
						count.addChildren(counter, firstOfTheSplittedLeaves);
						else{
							count.removeChildren(99-counter);
						}
					}

							parent.removeChildren(IndexOfTheInsertingPlaceForChildren);
							firstOfTheSplittedLeaves.setParent(parent);
							lastOfTheSplittedLeaves.setParent(parent);
							parent.addChildren(IndexOfTheInsertingPlaceForChildren,firstOfTheSplittedLeaves);
							parent.addChildren(IndexOfTheInsertingPlaceForChildren+1,lastOfTheSplittedLeaves);
							return primaryRoot;
				}
				else//there is push up operation
				{
						
							int push_up_key = parent.audioIdAtIndex(orderForPlaylistTree);
							ArrayList<PlaylistNode> splitted_internals = split_internal_primary(parent,IndexOfTheInsertingPlaceForChildren,firstOfTheSplittedLeaves,lastOfTheSplittedLeaves);
							first_int =(PlaylistNodePrimaryIndex) splitted_internals.get(0);
							second_int = (PlaylistNodePrimaryIndex)splitted_internals.get(1);
							if(parent.getParent()==null){// create a new root,then done ->root can have 1 key
								
								root.addAudioId(0,push_up_key);
								first_int.setParent(root);
								second_int.setParent(root);
								root.addChildren(0,first_int);
								root.addChildren(1,second_int);
								return root;
							}
							else{

									parent = (PlaylistNodePrimaryIndex)parent.getParent();
									first_int.setParent(parent);
									second_int.setParent(parent);

									for(int i=0; i<parent.audioIdCount();i++){
										if(push_up_key < parent.audioIdAtIndex(i)){
											parent.addAudioId(i,push_up_key);
											IndexOfTheInsertingPlaceForChildren=i;
											break;
										}
										else if(i==parent.audioIdCount()-1){
											parent.addAudioId(i+1,push_up_key);
											IndexOfTheInsertingPlaceForChildren=i+1;
											break;
										}
									}
									root = (PlaylistNodePrimaryIndex)recursiveCallForPrimary(primaryRoot,parent,IndexOfTheInsertingPlaceForChildren,first_int,second_int);
							}
					}
					return root;
				


	}

	private PlaylistNode recursiveCallForSecondary(PlaylistNode secondaryRoot, PlaylistNode sourceSecondary,
			int index, PlaylistNode first, PlaylistNode second) {
				int order = PlaylistNode.order;
				PlaylistNodeSecondaryIndex parent = new PlaylistNodeSecondaryIndex(null);
				PlaylistNodeSecondaryIndex first_int= new PlaylistNodeSecondaryIndex(null);
				PlaylistNodeSecondaryIndex second_int= new PlaylistNodeSecondaryIndex(null);
				parent = (PlaylistNodeSecondaryIndex) sourceSecondary;
				PlaylistNodeSecondaryIndex root = new  PlaylistNodeSecondaryIndex(null);
				if(parent.genreCount()<=2*order)//done there is no push up
				{			

							parent.removeChildren(index);
							first.setParent(parent);
							second.setParent(parent);
							parent.addChildren(index,first);
							parent.addChildren(index+1,second);
							return secondaryRoot;
				}
				else{
								
					String pushGenre = parent.genreAtIndex(order);
					ArrayList<PlaylistNode> splitted_internals = split_internal_secondary(parent,index,first,second);
					first_int =(PlaylistNodeSecondaryIndex) splitted_internals.get(0);
					second_int = (PlaylistNodeSecondaryIndex)splitted_internals.get(1);
					if(parent.getParent()==null){// create a new root,then done ->root can have 1 key
						root.addGenre(0, pushGenre);
						first_int.setParent(root);
						second_int.setParent(root);
						root.addChildren(0,first_int);
						root.addChildren(1,second_int);
						return root;
					}
					else{

							parent = (PlaylistNodeSecondaryIndex)parent.getParent();
							first_int.setParent(parent);
							second_int.setParent(parent);

							for(int i=0; i<parent.genreCount();i++){
								if(parent.genreAtIndex(i).compareTo(pushGenre)>0){
									parent.addGenre(i,pushGenre);
									index=i;
									break;
								}
								else if(i==parent.genreCount()-1){
									parent.addGenre(i,pushGenre);
									index=i+1;
									break;
								}
							}
							root = (PlaylistNodeSecondaryIndex)recursiveCallForSecondary(secondaryRoot,parent,index,first_int,second_int);
					}


				}
				
				
				return root;
			}


	private ArrayList<PlaylistNode> split_leaves_primary(PlaylistNode leaf){
		PlaylistNodePrimaryLeaf sourcePrimary = (PlaylistNodePrimaryLeaf) leaf;
			int orderForPlaylistTree = PlaylistNode.order;
			ArrayList<CengSong> firstArrayForOverflowLeaf = new ArrayList<CengSong>();
			ArrayList<CengSong> secondArrayForOverflowLeaf = new ArrayList<CengSong>();
			for(int i=0; i<sourcePrimary.songCount() ; i++){
				if(i<orderForPlaylistTree)
					firstArrayForOverflowLeaf.add(sourcePrimary.songAtIndex(i));
				else
					secondArrayForOverflowLeaf.add(sourcePrimary.songAtIndex(i));
			}
			PlaylistNode firstLeafForOverflowLeaf = new PlaylistNodePrimaryLeaf(null,firstArrayForOverflowLeaf);
			PlaylistNode secondLeafForOverflowLeaf = new PlaylistNodePrimaryLeaf(null,secondArrayForOverflowLeaf);
			ArrayList<PlaylistNode> result = new ArrayList<PlaylistNode>();
			result.add(firstLeafForOverflowLeaf);
			result.add(secondLeafForOverflowLeaf);
			
			return result;
	}

	

	private ArrayList<PlaylistNode> split_leaves_secondary(PlaylistNode leaf){
		PlaylistNodeSecondaryLeaf sourceSecondary = (PlaylistNodeSecondaryLeaf) leaf;
			int order = PlaylistNode.order;
			ArrayList<ArrayList<CengSong>> first = new ArrayList<ArrayList<CengSong>>();
			ArrayList<ArrayList<CengSong>>  second = new ArrayList<ArrayList<CengSong>>();
			for(int i = 0 ;i<sourceSecondary.genreCount();i++){
				if(i<order){
					first.add(sourceSecondary.getSongBucket().get(i));
				}
				else
					second.add(sourceSecondary.getSongBucket().get(i));

			}
			PlaylistNode firstLeafForOverflowLeaf = new PlaylistNodeSecondaryLeaf(null,first);
			PlaylistNode secondLeafForOverflowLeaf = new PlaylistNodeSecondaryLeaf(null,second);
			ArrayList<PlaylistNode> result = new ArrayList<PlaylistNode>();
			result.add(firstLeafForOverflowLeaf);
			result.add(secondLeafForOverflowLeaf);
			
			return result;
	}

	private ArrayList<PlaylistNode> split_internal_primary(PlaylistNode internal, int IndexOfTheInsertingPlaceForChildren, PlaylistNode firstLeafForOverflowLeaf,PlaylistNode secondLeafForOverflowLeaf){
		PlaylistNodePrimaryIndex sourcePrimary = (PlaylistNodePrimaryIndex) internal;
		int orderForPlaylistTree = PlaylistNode.order;
		ArrayList<Integer> firstArrayForSplitInternal = new ArrayList<Integer>();
		ArrayList<Integer> secondArrayForSplitInternal = new ArrayList<Integer>();
		ArrayList<PlaylistNode> firstChildrenArrayForSplitInternal = new ArrayList<PlaylistNode>();
		ArrayList<PlaylistNode> secondChildrenArrayForSplitInternal = new ArrayList<PlaylistNode>();
		boolean boolean1=true;
		boolean boolean2=true;
		for(int i=0; i<= 2*orderForPlaylistTree;i++){
			if(i<orderForPlaylistTree){
				firstArrayForSplitInternal.add(sourcePrimary.audioIdAtIndex(i));
			}
			else if(i>orderForPlaylistTree){
				secondArrayForSplitInternal.add(sourcePrimary.audioIdAtIndex(i));
			
			}
		}
		int srcInd =0;
		for(int i=0;i<2*orderForPlaylistTree+2;i++){

			if(i<=orderForPlaylistTree && i<IndexOfTheInsertingPlaceForChildren){
				firstChildrenArrayForSplitInternal.add(sourcePrimary.getChildrenAt(srcInd));
				srcInd++;

			}
			else if(i<=orderForPlaylistTree && i==IndexOfTheInsertingPlaceForChildren){
				firstChildrenArrayForSplitInternal.add(firstLeafForOverflowLeaf);
				boolean1=true;

			}
			else if(i<=orderForPlaylistTree && i==IndexOfTheInsertingPlaceForChildren+1){
				firstChildrenArrayForSplitInternal.add(secondLeafForOverflowLeaf);
				srcInd++;
				boolean2=true;

			}
			else if(i<=orderForPlaylistTree && i>IndexOfTheInsertingPlaceForChildren+1){
				firstChildrenArrayForSplitInternal.add(sourcePrimary.getChildrenAt(srcInd));
				srcInd++;

			}
			else if(i>orderForPlaylistTree && i<IndexOfTheInsertingPlaceForChildren){
				secondChildrenArrayForSplitInternal.add(sourcePrimary.getChildrenAt(srcInd));
				srcInd++;
			}
			else if(i>orderForPlaylistTree && i>IndexOfTheInsertingPlaceForChildren+1){
				secondChildrenArrayForSplitInternal.add(sourcePrimary.getChildrenAt(srcInd));
				srcInd++;

			}
			else if(i>orderForPlaylistTree && i== IndexOfTheInsertingPlaceForChildren){
				secondChildrenArrayForSplitInternal.add(firstLeafForOverflowLeaf);

				boolean1=false;

			}
			else if(i>orderForPlaylistTree && i==IndexOfTheInsertingPlaceForChildren+1){
				secondChildrenArrayForSplitInternal.add(secondLeafForOverflowLeaf);
				srcInd++;
				boolean2=false;
			}
		}
		PlaylistNode firstOfTheSplittedLeaves =new  PlaylistNodePrimaryIndex(null, firstArrayForSplitInternal,firstChildrenArrayForSplitInternal);
		PlaylistNode second =new  PlaylistNodePrimaryIndex(null, secondArrayForSplitInternal,secondChildrenArrayForSplitInternal);
		for(PlaylistNode child: ((PlaylistNodePrimaryIndex) firstOfTheSplittedLeaves).getAllChildren()){
				child.setParent(firstOfTheSplittedLeaves);
		}
		for(PlaylistNode child: ((PlaylistNodePrimaryIndex) second).getAllChildren()){
				child.setParent(second);
		}
		ArrayList<PlaylistNode> result =new ArrayList<PlaylistNode>();
		if(boolean1)
			firstLeafForOverflowLeaf.setParent(firstOfTheSplittedLeaves);
		else
			firstLeafForOverflowLeaf.setParent(second);
		if(boolean2)
			secondLeafForOverflowLeaf.setParent(firstOfTheSplittedLeaves);
		else
			secondLeafForOverflowLeaf.setParent(second);
		result.add(firstOfTheSplittedLeaves);
		result.add(second);
		return result;
	}

	private ArrayList<PlaylistNode> split_internal_secondary(PlaylistNode internal, int index, PlaylistNode first,PlaylistNode second){
		PlaylistNodeSecondaryIndex sourceSecondary = (PlaylistNodeSecondaryIndex) internal;
		int order = PlaylistNode.order;
		ArrayList<String> array_first_int = new ArrayList<String>();
		ArrayList<String> array_second_int = new ArrayList<String>();
		ArrayList<PlaylistNode> first_children_arr = new ArrayList<PlaylistNode>();
		ArrayList<PlaylistNode> second_children_arr = new ArrayList<PlaylistNode>();
		boolean boolean1=true;
		boolean boolean2=true;
		for(int i=0; i<= 2*order;i++){
			if(i<order){
				array_first_int.add(sourceSecondary.genreAtIndex(i));
			}
			else if(i>order){
				array_second_int.add(sourceSecondary.genreAtIndex(i));
			
			}
		}
		int srcInd =0;
		for(int i=0;i<2*order+2;i++){

			if(i<=order && i<index){
				first_children_arr.add(sourceSecondary.getChildrenAt(srcInd));
				srcInd++;

			}
			else if(i<=order && i==index){
				first_children_arr.add(first);
				boolean1=true;

			}
			else if(i<=order && i==index+1){
				first_children_arr.add(second);
				srcInd++;
				boolean2=true;

			}
			else if(i<=order && i>index+1){
				first_children_arr.add(sourceSecondary.getChildrenAt(srcInd));
				srcInd++;

			}
			else if(i>order && i<index){
				second_children_arr.add(sourceSecondary.getChildrenAt(srcInd));
				srcInd++;
			}
			else if(i>order && i>index+1){
				second_children_arr.add(sourceSecondary.getChildrenAt(srcInd));
				srcInd++;

			}
			else if(i>order && i== index){
				second_children_arr.add(first);

				boolean1=false;

			}
			else if(i>order && i==index+1){
				second_children_arr.add(second);
				srcInd++;
				boolean2=false;
			}
		}
		PlaylistNode firstOfTheSplittedLeaves =new  PlaylistNodeSecondaryIndex(null, array_first_int,first_children_arr);
		PlaylistNode secondXX =new  PlaylistNodeSecondaryIndex(null, array_second_int,second_children_arr);
		for(PlaylistNode child: ((PlaylistNodeSecondaryIndex) firstOfTheSplittedLeaves).getAllChildren()){
				child.setParent(firstOfTheSplittedLeaves);
		}
		for(PlaylistNode child: ((PlaylistNodeSecondaryIndex) secondXX).getAllChildren()){
				child.setParent(second);
		}
		ArrayList<PlaylistNode> result =new ArrayList<PlaylistNode>();
		if(boolean1)
		first.setParent(firstOfTheSplittedLeaves);
		else
		first.setParent(secondXX);
		if(boolean2)
		first.setParent(firstOfTheSplittedLeaves);
		else
		first.setParent(secondXX);
		result.add(firstOfTheSplittedLeaves);
		result.add(secondXX);
		return result;
	}
		
	
	public CengSong searchSong(Integer audioId) {
		PlaylistNode search = primaryRoot;
		int lastIndex = 0;
		for(int i=0;search.type==PlaylistNodeType.Internal;i++){
			ArrayList<Integer> audioIds = ((PlaylistNodePrimaryIndex) search).getaudioIds();
			int index = 0; 
			for(int x = 0 ; x< audioIds.size();x++){
				if(audioIds.get(x)> audioId){
					index = x;
					break;
				}
				else if(x==audioIds.size()-1)index = x+1;
			}
			tabber(i);
			System.out.println("<index>");
			for(int x = 0; x<audioIds.size();x++){
			tabber(i);
				System.out.println(audioIds.get(x));

			}
			tabber(i);

			System.out.println("</index>");
			PlaylistNode child = ((PlaylistNodePrimaryIndex) search).getChildrenAt(index);
			search = child;
			lastIndex= i;
		}
		ArrayList<CengSong> songs = ((PlaylistNodePrimaryLeaf) search).getSongs();
		CengSong find = null;
		for(CengSong song : songs){
			if(song.audioId()==audioId){
				find = song;
				break;
			}	
		}

		if(find==null){
			tabber(lastIndex+1);

			System.out.println("Could not find " + audioId);
		}

		else{
		tabber(lastIndex+1);
			
			System.out.println("<data>");
			tabber(lastIndex+1);

			System.out.println("<record>" + find.audioId() + "|" + find.genre() + "|" + find.artist() + "|" + find.songName() + "</record>");
			tabber(lastIndex+1);
			
			System.out.println("</data>");
		}
		return null;
	}
	

	public void printPrimaryPlaylist() {
		printPrimaryPlaylistRecursive(primaryRoot,0);
		return;
	}
	
	
	public void printSecondaryPlaylist() {
		printSecondaryPlaylistRecursive(secondaryRoot,0);
		return;
	}
	
	
	// Extra functions if needed
	public void printSecondaryPlaylistRecursive(PlaylistNode root, int tabCount){
		if(root.getType() == PlaylistNodeType.Leaf){
			tabber(tabCount);
			System.out.println("<data>");
			ArrayList<ArrayList<CengSong>> songBuckets = ((PlaylistNodeSecondaryLeaf)root).getSongBucket();
			for(int k=0 ; k < ((PlaylistNodeSecondaryLeaf)root).genreCount();k++ ){
				ArrayList<CengSong> songs = songBuckets.get(k);
				String genre="";
				for(CengSong song :songs){
					if(!genre.equals(song.genre())){
						tabber(tabCount);
						System.out.println(song.genre());

					}
				genre=song.genre();
				tabber(tabCount+1);
				System.out.println("<record>"+song.audioId()+"|"+song.genre()+"|"+song.artist()+"|"+song.songName()+"</record>");
			}
		}
			tabber(tabCount);
			System.out.println("</data>");
		}
		else{
			tabber(tabCount);
			System.out.println("<index>");
			for(int k=0; k<((PlaylistNodeSecondaryIndex)root).genreCount();k++){
				tabber(tabCount);
				System.out.println(((PlaylistNodeSecondaryIndex)root).genreAtIndex(k));
			}
				tabber(tabCount);
				System.out.println("</index>");
			for(int i=0; i<((PlaylistNodeSecondaryIndex)root).genreCount()+1;i++){
				printSecondaryPlaylistRecursive(((PlaylistNodeSecondaryIndex)root).getChildrenAt(i),tabCount+1);
			}

		}
	}
	public void printPrimaryPlaylistRecursive(PlaylistNode root, int tabCount){
		if(root.getType() == PlaylistNodeType.Leaf){
			tabber(tabCount);
			System.out.println("<data>");
			for(int k=0 ; k < ((PlaylistNodePrimaryLeaf)root).songCount();k++ ){
				CengSong song = ((PlaylistNodePrimaryLeaf)root).songAtIndex(k);
				tabber(tabCount);
				System.out.println("<record>"+song.audioId()+"|"+song.genre()+"|"+song.artist()+"|"+song.songName()+"</record>");
			}
			tabber(tabCount);
			System.out.println("</data>");
		}
		else{
			tabber(tabCount);
			System.out.println("<index>");
			for(int k=0; k<((PlaylistNodePrimaryIndex)root).audioIdCount();k++){
				tabber(tabCount);
				System.out.println(((PlaylistNodePrimaryIndex)root).audioIdAtIndex(k));
			}
				tabber(tabCount);
				System.out.println("</index>");
			for(int i=0; i<((PlaylistNodePrimaryIndex)root).audioIdCount()+1;i++){
				printPrimaryPlaylistRecursive(((PlaylistNodePrimaryIndex)root).getChildrenAt(i),tabCount+1);
			}

		}
	}
	public void tabber(int count){
		for(int j = 0 ; j<count;j++){
			System.out.print("\t");
			}
	}
	
}


